#!/usr/bin/python
# -*- coding: utf-8 -*-
import math
import random
import pygame
from code.system.managers.assetmanager import AssetManager
from code.system.config import ENTITY_SPEED, ENTITY_SHOT_DELAY
from code.shots.enemyshot import EnemyShot
from code.CombatEntity.combatentity import CombatEntity

class Enemy(CombatEntity):
    def __init__(self, name: str, position: tuple, window):
        super().__init__(name, position)
        self.window = window
        self.shot_delay = ENTITY_SHOT_DELAY[self.name]

        if self.name == "Enemy1":
            self.anim_frames = [
                AssetManager.get_image("Enemy1_1.png"),
                AssetManager.get_image("Enemy1_2.png"),
                AssetManager.get_image("Enemy1_3.png")
            ]
            self.anim_index = 0
            self.anim_timer = 0



        if self.name == "Enemy2":
            self.zigzag_timer = 0
            self.zigzag_direction = 0
            self.anim_frames = [
                AssetManager.get_image("Enemy2_1.png"),
                AssetManager.get_image("Enemy2_2.png"),
                AssetManager.get_image("Enemy2_3.png")
            ]
            self.anim_index = 0
            self.anim_timer = 0

    def move(self):
        if getattr(self, 'frozen', False):
            return

        self.rect.centerx -= ENTITY_SPEED[self.name]

        if self.name == "Enemy2":
            if self.zigzag_timer > 0:
                next_y = self.rect.centery + self.zigzag_direction * 2
                if 30 < next_y < self.window.get_height() - 30:
                    self.rect.centery = next_y
                self.zigzag_timer -= 1
            else:
                if random.random() < 0.3:
                    self.zigzag_direction = random.choice([-1, 1])
                    self.zigzag_timer = random.randint(20, 60)
                else:
                    self.zigzag_direction = 0

    def update(self):
        self.move()

        if self.name == "Enemy1":
            self.anim_timer += 1
            if self.anim_timer >= 10:
                self.anim_timer = 0
                self.anim_index = (self.anim_index + 1) % len(self.anim_frames)

        if self.name == "Enemy2":
            self.anim_timer += 1
            if self.anim_timer >= 10:
                self.anim_timer = 0
                self.anim_index = (self.anim_index + 1) % len(self.anim_frames)

    def shoot(self):
        if getattr(self, 'frozen', False):
            return None

        self.shot_delay -= 1
        if self.shot_delay <= 0:
            if self.name == "Enemy1":
                self.shot_delay = random.randint(70, 130)
            else:
                self.shot_delay = ENTITY_SHOT_DELAY[self.name]

            try:
                sound = AssetManager.get_sound(f"{self.name}Shot.mp3")
                sound.set_volume(0.4)
                sound.play()
            except Exception as e:
                print(f"[Erro ao tocar som de {self.name}] {e}")

            return EnemyShot(name=f'{self.name}Shot', position=(self.rect.centerx, self.rect.centery))

        return None

    def draw(self, surface):

        if self.name == "Enemy1":
            surface.blit(self.surf, self.rect)  # hitbox invisível
            frame = self.anim_frames[self.anim_index]
            anim_rect = frame.get_rect(center=self.rect.center)
            surface.blit(frame, anim_rect)

        elif self.name == "Enemy2":
            frame = self.anim_frames[self.anim_index]
            offset = math.sin(pygame.time.get_ticks() * 0.005 + self.rect.x * 0.01) * 1.5
            angle = math.sin(pygame.time.get_ticks() * 0.002 + self.rect.x * 0.01) * 3
            rotated = pygame.transform.rotate(frame, angle)
            rect = rotated.get_rect(center=(self.rect.centerx, self.rect.centery + offset))
            surface.blit(rotated, rect)

        elif self.name == "Enemy3":
            frame = self.anim_frames[self.anim_index]
            offset = math.sin(pygame.time.get_ticks() * 0.004 + self.rect.x * 0.015) * 2
            angle = math.sin(pygame.time.get_ticks() * 0.003 + self.rect.x * 0.012) * 3
            rotated = pygame.transform.rotate(frame, angle)
            rect = rotated.get_rect(center=(self.rect.centerx, self.rect.centery + offset))
            surface.blit(rotated, rect)


        else:
            # fallback para qualquer outro tipo
            surface.blit(self.surf, self.rect)

class Enemy3(Enemy):
    def __init__(self, window):
        x = window.get_width() + 20
        y = random.randint(50, window.get_height() - 50)
        super().__init__(name="Enemy3", position=(x, y), window=window)

        self.anim_frames = [
            AssetManager.get_image("Enemy3_1.png"),
            AssetManager.get_image("Enemy3_2.png"),
            AssetManager.get_image("Enemy3_3.png")
        ]
        self.anim_index = 0
        self.anim_timer = 0

        self.health = 110
        self.speed = 2.0
        self.damage = 12
        self.score = 150
        self.last_shot_time = pygame.time.get_ticks()
        self.shot_delay = random.randint(10, 20)
        self.behavior_timer = 0
        self.state = "moving"  # ou "idle"


    def move(self):
        if self.state == "moving":
            self.rect.centerx -= self.speed
            self.behavior_timer += 1
            if self.behavior_timer > 180:
                self.state = "idle"
                self.behavior_timer = 0
        elif self.state == "idle":
            self.behavior_timer += 1
            if self.behavior_timer > 120:
                self.state = "moving"
                self.behavior_timer = 0

    def update(self):
        self.move()
        shot = self.shoot()
        self.anim_timer += 1
        if self.anim_timer >= 10:
            self.anim_timer = 0
            self.anim_index = (self.anim_index + 1) % len(self.anim_frames)

        if shot:
            self.entity_manager.add_entity(shot)

    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_shot_time >= self.shot_delay:
            self.last_shot_time = now
            self.shot_delay = random.randint(1000, 1800)  # randomiza delay para parecer natural

            # calcula direção para o player mais próximo
            players = self.entity_manager.get_players()
            if not players:
                return None

            target = min(players, key=lambda p: abs(p.rect.centery - self.rect.centery))
            direction = pygame.Vector2(-1, target.rect.centery - self.rect.centery).normalize()

            return EnemyShot(name="Enemy3Shot", position=self.rect.center, direction=direction)

        return None



