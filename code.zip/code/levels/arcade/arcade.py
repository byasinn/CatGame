
class Arcade:
    pass