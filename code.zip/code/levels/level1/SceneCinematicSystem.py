from code.settings.lang import t

def create_scene_data_1():
    return t("scenes1")

def create_scene_data_2():
    return t("scenes2")

def create_scene_data_3():
    return t("scenes3")

def get_scene_data(scene_key):
    return t(scene_key)

