import sys
import pygame
import math
from pygame import Surface
from code.settings.settingsmanager import SettingsManager
from code.system.assetmanager import AssetManager
from code.system.config import MENU_OPTION
from code.system.entitymanager import EntityManager
from code.system.entity import Entity
from code.factory.entityFactory import EntityFactory
from code.core.hud import HUDRenderer
from code.system.eventcontroller import EventController
from code.settings.lang import t

# Importa os novos módulos separados
from code.levels.level1.tutorialmanager import TutorialManager
from code.levels.level1.cutscenes1 import CutsceneManager

class Level1_0:
    def __init__(self, window: Surface, game_mode: str, player_score: list[int], audio=None):
        self.window = window
        self.name = "Level1"
        self.game_mode = game_mode
        self.audio = audio
        self.entity_list: list[Entity] = []

        # Cria jogador
        self.player = EntityFactory.get_entity('Player1', window=window)
        self.player.score = player_score[0]
        self.entity_list.append(self.player)

        # Segundo jogador se modo cooperativo
        if game_mode in [MENU_OPTION[1], MENU_OPTION[2]]:
            self.player2 = EntityFactory.get_entity('Player2', window=window)
            self.player2.score = player_score[1]
            self.entity_list.append(self.player2)

        # Carrega fundo
        self.entity_list.extend(EntityFactory.get_entity("Level1Bg"))

        # Setup geral
        self.entity_manager = EntityManager(self.entity_list, self.window)
        self.event_controller = EventController(self.entity_manager, EntityFactory)
        self.hud = HUDRenderer(self.window)
        self.sunlight = AssetManager.get_image("LightOverlay_Level1.png")

        self.effects_enabled = SettingsManager.get("visual_effects")
        self.entity_manager.enable_ambient_particles = self.effects_enabled
        self.entity_manager.enable_magic_fog = self.effects_enabled
        self.player.entity_manager = self.entity_manager

        # Managers externos (tutorial e cutscene)
        self.tutorial_manager = TutorialManager(self.entity_manager, self.window, self.player)
        self.cutscene_manager = CutsceneManager(self.window, self.player)

    def run(self, player_score: list[int]):
        if self.audio:
            self.audio.play_music("level1")

        clock = pygame.time.Clock()

        while True:
            dt = clock.tick(60)
            self.window.fill((0, 0, 0))
            event_list = pygame.event.get()

            for event in event_list:
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.event_controller.handle(event_list)

            self.entity_manager.update_entities()
            self.entity_manager.handle_collisions()

            self.entity_manager.draw_backgrounds()
            self.entity_manager.draw_entities()
            self.entity_manager.draw_particles()
            self.entity_manager.update_visual_effects()

            # Tutorial ou cutscene
            if not self.tutorial_manager.done:
                self.tutorial_manager.update()
            else:
                self.cutscene_manager.update(event_list)

            pygame.display.flip()

            if self.cutscene_manager.done:
                import time
                time.sleep(1)
                return True
