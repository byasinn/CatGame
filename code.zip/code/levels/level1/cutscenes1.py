import pygame
import math
from code.system.assetmanager import AssetManager

class CutsceneManager:
    def __init__(self, window, player):
        self.window = window
        self.player = player
        self.done = False
        self.phase = 0

        self.dialogue_list = [
            ("npc", "Que bom que você já chegou, eles estão por toda parte!"),
            ("player", "Onde? Quem?"),
            ("npc", "Fique atento, não confie em ninguém!"),
        ]
        self.npc_img = AssetManager.get_image("NpcSprite.png")
        self.npc_pos_x = window.get_width() + 100
        self.npc_target_x = window.get_width() // 2 + 80

    def update(self, event_list):
        # NPC se move da direita até o centro
        if self.npc_pos_x > self.npc_target_x:
            self.npc_pos_x -= 6

        npc_y = self.window.get_height() // 2 + math.sin(pygame.time.get_ticks() * 0.005) * 8
        npc_rect = self.npc_img.get_rect(center=(self.npc_pos_x, npc_y))
        self.window.blit(self.npc_img, npc_rect)

        if self.npc_pos_x <= self.npc_target_x:
            if self.phase < len(self.dialogue_list):
                speaker, message = self.dialogue_list[self.phase]
                font = pygame.font.Font("./asset/PressStart2P-Regular.ttf", 14)
                wrapped_lines = self.render_wrapped_text(message, font, self.window.get_width() // 2.5)

                if speaker == "npc":
                    base_pos = (npc_rect.centerx, npc_rect.top - 30)
                else:
                    base_pos = (self.player.rect.centerx, self.player.rect.top - 30)

                for i, line in enumerate(wrapped_lines):
                    rect = line.get_rect(center=(base_pos[0], base_pos[1] + i * 18))
                    self.window.blit(line, rect)

                for event in event_list:
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                        self.phase += 1
            else:
                self.done = True

    def render_wrapped_text(self, text, font, max_width):
        words = text.split(" ")
        lines = []
        current = ""
        for word in words:
            test = current + word + " "
            if font.size(test)[0] < max_width:
                current = test
            else:
                lines.append(font.render(current.strip(), True, (255, 255, 255)))
                current = word + " "
        if current:
            lines.append(font.render(current.strip(), True, (255, 255, 255)))
        return lines
