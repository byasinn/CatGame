import sys
import pygame
from pygame import Surface
from code.settings.settingsmanager import SettingsManager
from code.system.assetmanager import AssetManager
from code.system.config import MENU_OPTION
from code.system.entitymanager import EntityManager
from code.system.entity import Entity
from code.factory.entityFactory import EntityFactory
from code.core.hud import HUDRenderer
from code.system.eventcontroller import EventController
from code.settings.lang import t

class Level1_0:
    def __init__(self, window: Surface, game_mode: str, player_score: list[int], audio=None):
        self.window = window
        self.name = "Level1"
        self.game_mode = game_mode
        self.audio = audio
        self.entity_list: list[Entity] = []

        self.tutorial_step = 0
        self.tutorial_done = False
        self.tutorial_text_timer = 0
        self.text_delay = 60  # 1 segundo
        self.enemy_spawned = False
        self.enemy_defeated = False

        self.font = pygame.font.Font("./asset/PressStart2P-Regular.ttf", 16)

        # Criar jogador
        self.player = EntityFactory.get_entity('Player1', window=window)
        self.player.score = player_score[0]
        self.entity_list.append(self.player)

        if game_mode in [MENU_OPTION[1], MENU_OPTION[2]]:
            self.player2 = EntityFactory.get_entity('Player2', window=window)
            self.player2.score = player_score[1]
            self.entity_list.append(self.player2)

        self.entity_list.extend(EntityFactory.get_entity("Level1Bg"))

        self.entity_manager = EntityManager(self.entity_list, self.window)
        self.event_controller = EventController(self.entity_manager, EntityFactory)
        self.hud = HUDRenderer(self.window)

        self.sunlight = AssetManager.get_image("LightOverlay_Level1.png")

        self.effects_enabled = SettingsManager.get("visual_effects")
        self.entity_manager.enable_ambient_particles = self.effects_enabled
        self.entity_manager.enable_magic_fog = self.effects_enabled

        self.player.entity_manager = self.entity_manager  # permite ao player adicionar tiros

    def run(self, player_score: list[int]):
        if self.audio:
            self.audio.play_music("level1")

        clock = pygame.time.Clock()

        while True:
            dt = clock.tick(60)
            self.window.fill((0, 0, 0))
            event_list = pygame.event.get()

            for event in event_list:
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.event_controller.handle(event_list)

            # Atualiza entidades se tutorial permitir
            if self.tutorial_step < 3:
                self.entity_manager.update_selected_entities(["Player1", "Player2"])
            else:
                self.entity_manager.update_entities()
                self.entity_manager.handle_collisions()

            self.entity_manager.draw_backgrounds()
            self.entity_manager.draw_entities()
            self.entity_manager.draw_particles()
            self.entity_manager.update_visual_effects()

            self.update_tutorial()

            pygame.display.flip()

            if self.tutorial_done:
                import time
                time.sleep(1)
                return True  # Retorna para iniciar próximo nível

    def update_tutorial(self):
        keys = pygame.key.get_pressed()
        player = self.player

        if self.tutorial_step == 0:
            self.draw_text("Mova-se com as setas ou WASD")
            if keys[pygame.K_LEFT] or keys[pygame.K_RIGHT] or keys[pygame.K_a] or keys[pygame.K_d]:
                self.tutorial_step += 1

        elif self.tutorial_step == 1:
            self.draw_text("Atire com Ctrl")
            if player.shot_fired:
                self.tutorial_step += 1

        elif self.tutorial_step == 2:
            self.draw_text("Derrote o inimigo!")
            if not self.enemy_spawned:
                enemy = EntityFactory.get_entity("EnemyTest", window=self.window)
                enemy.hp = 1
                self.entity_manager.add_entity(enemy)
                self.enemy_spawned = True
            if self.enemy_spawned and not any(e.name == "EnemyTest" for e in self.entity_manager.get_entities()):
                self.tutorial_step += 1

        elif self.tutorial_step == 3:
            self.draw_text("Parabens! Prepare-se...")
            self.tutorial_done = True

    def draw_text(self, message: str):
        text = self.font.render(message, True, (255, 255, 255))
        rect = text.get_rect(center=(self.window.get_width() // 2, self.window.get_height() // 4))
        self.window.blit(text, rect)

class Level1:
    pass