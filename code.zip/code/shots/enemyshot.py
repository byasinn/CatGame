import pygame
from code.system.config import ENTITY_SPEED
from code.CombatEntity.combatentity import CombatEntity


class EnemyShot(CombatEntity):
    def __init__(self, name, position, direction=None):
        super().__init__(name, position)
        self.direction = direction or pygame.Vector2(-1, 0)  # padrão: vai para a esquerda
        self.speed = 5  # ou o valor apropriado

    def update(self):
        self.rect.centerx += self.direction.x * self.speed
        self.rect.centery += self.direction.y * self.speed

    def move(self):
        self.rect.centerx -= ENTITY_SPEED[self.name]

    def draw(self, surface):
        surface.blit(self.image, self.rect)
